---
title: "Imprint & Legal Disclosure"
draft: false
layout: "simple-page"
---

Owner, author, editor, and responsible for all content on nocamerabag.com ("this site") is:Christian Feichtner, Vienna, Austria

## Contact

eMail: hello@nocamerabag.com

For additional ways to contact me, see contact.

## Editorial Policy & Orientation of this Web-Site

This site is a private project that solely represents my personal opinion and experience. It is about my travels and my experience with and approach to iPhone photography while traveling.

This website and its content are neither endorsed nor sponsored in part or total by my former, current or future employers. Views and opinions published on this site are my own.

## Connected Accounts

All information on this page also applies to social media accounts connected with this website, which are:

* Instagram: http://instagram.com/nocamerabag
* Flickr: http://flickr.com/photos/chrisfeichtner
* Facebook: http://facebook.com/nocamerabag
* Pinterest: http://pinterest.com/nocamerabag

Please also check the Terms & Conditions and Image Licensing pages.
